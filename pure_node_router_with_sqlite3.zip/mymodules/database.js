class Db {

    constructor() { }

    getConnection() {
        const sqlite3 = require('sqlite3').verbose();
        const dbconn = new sqlite3.Database('./db/mydata.db');
        return dbconn;
    }

    createTableLinks(conn) {
        conn.run(
            `CREATE TABLE IF NOT EXISTS links (
                link_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                link_name TEXT NOT NULL
            )`
        );
        conn.close();
    }

    insertLink(conn, linkName) {
        conn.run(`INSERT INTO links (link_name) VALUES (?)`,[linkName], function(err) {
            if (err) {
                return console.log(err.message);
            }
            console.log(`A new record has been inserted with rowid ${this.lastID}`);
        });
        conn.close();
    }

    dropTableLinks(conn) {
        conn.run(`DROP TABLE links`);
        conn.close();
    }
    
    getAllRows = (conn) => {
        return new Promise((resolve, reject) => {
            let sql = `SELECT * from links`;
            let result = []
            conn.each(sql, (err, row) => {
                if(err) { 
                    reject(err) 
                }
                result.push(row)
            }, () => {
                resolve(result)
            })
        })
    }

    runMigrations() {
        let conn = this.getConnection();
        this.createTableLinks(conn);
        this.insertLink(conn, 'JS Data Types');
        this.insertLink(conn, 'JS Functions');
        conn.close();
    }



}

module.exports = Db;