const http = require('http');
const fs = require('fs');
const url = require('url');
const path = require('path');

const Db = require('./mymodules/database.js');

const baseUrl = __dirname; // baseUrl: C:\mydocs\ns

const server = http.createServer();

server.on('request', (request, response) => {
    const index_file = fs.readFileSync('./static/views/index.html');
    const pathName = url.parse(request.url, true).pathname;
    //const query = url.parse(req.url, true).query;
    //const id = url.parse(req.url, true).query.id;
    if (pathName === '/') {
        response.writeHead(200, {'Content-Type': 'text/html'});
        //res.sendFile(path.join(__dirname + '/static/views/index.html')); // yep
        response.end(index_file);
    }
});

server.on('request', (request, response) => {
    const pathName = url.parse(request.url, true).pathname;
    if (pathName === '/favicon.ico') {
        response.writeHead(204, {'Content-Type': 'image/x-icon'});
    }
});
/*
server.on('request', (request, response) => {
    const about_file = fs.readFileSync('./static/views/about.html');
    const pathName = url.parse(request.url, true).pathname;
    if (pathName === '/about') {
        response.writeHead(200, {'Content-Type': 'text/html'});
        response.end(about_file); 
    }
});

server.on('request', (request, response) => {
    const pathName = url.parse(request.url, true).pathname;
    if (pathName === '/test1') {
        response.writeHead(200, {'Content-Type': 'text/html'});
        response.end('This is the TEST 1 page'); 
    }
});

server.on('request', (request, response) => {
    const vue_file = fs.readFileSync('./static/vue/vue.global.js');
    const pathName = url.parse(request.url, true).pathname;
    if (pathName === '/static/vue/vue.global.js') {
        response.writeHead(200, {'Content-Type': 'text/javascript'});
        response.end(vue_file);
    }
});
*/
server.on('request', (request, response) => {
    const pathName = url.parse(request.url, true).pathname;
    if (pathName === '/testJsonResp') {
        let responseData = {test: "pass", isValid: 1};
        const jsonContent = JSON.stringify(responseData);
        response.writeHead(200, {'Content-Type': 'application/json'});
        response.end(jsonContent);
    } 
});

server.on('request', (request, response) => {
    const pathName = url.parse(request.url, true).pathname;
    if (pathName === '/contacts') {
        let header_tpl = fs.readFileSync('./static/views/header.html');
        let contacts_tpl = fs.readFileSync('./static/views/contacts_tpl.html');
        let footer_tpl = fs.readFileSync('./static/views/footer.html');
        response.writeHead(200, {'Content-Type': 'text/html'});
        response.write(header_tpl.toString());
        response.write(contacts_tpl.toString());
        response.write(footer_tpl.toString());
        response.end();
    }
});

//-------------

server.on('request', (request, response) => {
  const pathName = url.parse(request.url, true).pathname;
  if (pathName === '/migrate') {
    const db = new Db();
    const conn = db.getConnection();
    //db.dropTableLinks(conn);
    //db.createTableLinks(conn);
    //db.insertLink(conn, 'JS Data Types');
    //db.insertLink(conn, 'JS Functions');
  }
});

server.on('request', (request, response) => {
  const pathName = url.parse(request.url, true).pathname;
  if (pathName === '/display_links') {
    const db = new Db();
    const conn = db.getConnection();
    db.getAllRows(conn).then((rows) => {
        console.log(rows);
        /* Output at console:
        [
            { link_id: 1, link_name: 'JS Data Types' },
            { link_id: 2, link_name: 'JS Functions' }
        ]
        */
    })
  }
});

server.listen(8000);









